#from django.conf.urls import url,include
from django.urls import path
from . import views

urlpatterns = [
    #url(r'^$', views.index, name="index"),
    #url(r'analyze', views.analyzeData, name="Analyzer"),
    path("index/",views.index,name="index"),
    path("analyze/",views.analyzeData,name="Analyzer"),
    path("",views.home,name="homepage"),
    path("about/",views.about,name="AboutUs"),
    path("contact/",views.contact,name="ContactUs"),
    path("signup/",views.handleSignup,name="handleSignup"),
    path("login/",views.handleLogin,name="handleLogin"),
    path("logout/",views.handleLogout,name="handleLogout"),
]