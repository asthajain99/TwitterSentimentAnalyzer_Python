import tweepy

consumer_key = "EabXxjqq8vEteFu9gMThl0aYx"
consumer_secret = "qn1C9oUDsNg7yyF9XdKZ0JpI7RYvtFcsMvenzBXSpjTEGQ7dhs"

access_token = "1173229675948019713-llMkkEcxzlKngwyp19M4wSguKdwWTT"
access_token_secret = "ujZsBIzoWabDQc1qa8leKSREGBRz8FdsYDQm1BSxljqFl"


class FetchData():

    def getTwitterData(self, tag):
        try:
            auth = tweepy.OAuthHandler(consumer_key, consumer_secret)
            auth.set_access_token(access_token, access_token_secret)

            api = tweepy.API(auth)

            public_tweets = api.search( q = tag, count=100,language = 'en' )

            return public_tweets

        except tweepy.TweepError as e:
            print("Error : " + str(e))
