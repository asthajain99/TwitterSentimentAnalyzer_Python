from django.shortcuts import render,redirect
from django.http import HttpResponse
from django.contrib import messages
from .models import Contact
from django.contrib.auth.models import User
from django.contrib.auth import authenticate,login,logout
from sentimentAnalyzer.util.sentimental import Analyzer

# Create your views here.

def index(request):
    return render(request,'sentimentAnalyzer/index.html')

def home(request):
    return render(request,'sentimentAnalyzer/homepage.html')

def about(request):
    return render(request, 'sentimentAnalyzer/about.html')

def contact(request):
    if request.method=="POST":
        name=request.POST.get('name','')
        email=request.POST.get('email','')
        phone=request.POST.get('phone','')
        desc=request.POST.get('desc','')
        if len(name)<2 or len(email)<3 or len(phone)<10 or len(desc)<4:
            messages.error(request,"Please fill the form correctly")
        else:
            contact=Contact(name=name,email=email,phone=phone,desc=desc)
            contact.save()
            messages.success(request,"Your message has been successfully sent")
    return render(request, 'sentimentAnalyzer/contact.html')

def handleSignup(request):
    if request.method=='POST':
        #Get the post paramaters
        username=request.POST['username']
        fname=request.POST['fname']
        lname=request.POST['lname']
        email=request.POST['email']
        pass1=request.POST['pass1']
        pass2=request.POST['pass2']

        #Check for errorneous inputs
        #username should be under 10 characters
        if len(username)>10:
            messages.error(request, "Username must be under 10 characters")
            return redirect('/')

        #username should be alphanumeric
        if not username.isalnum():
            messages.error(request, "Username should only contain letters and numbers")
            return redirect('/')

        #passwords should match
        if pass1!=pass2:
            messages.error(request, "Passwords donot match")
            return redirect('/')

        #Create the user
        myuser=User.objects.create_user(username,email,pass1)
        myuser.first_name=fname
        myuser.last_name=lname
        myuser.save()
        messages.success(request, "Your account has been successfully created")
        return redirect('/')
    else:
        return HttpResponse('404-Not Found')

def analyzeData(request):
    if request.method == 'GET':

        req_tag = request.GET.get("searchTag")

        analyzer = Analyzer()
        analyzed_data = analyzer.analyzeData(req_tag)
        analyzed_data['tag'] = '#' + req_tag.upper()
        #print(analyzed_data)
        return render(request,'sentimentAnalyzer/analysis.html', analyzed_data)

def handleLogin(request):
    if request.method=='POST':
        #Get the post paramaters
        loginusername=request.POST['loginusername']
        loginpassword=request.POST['loginpassword']

        user=authenticate(username=loginusername,password=loginpassword)

        if user is not None:
            login(request,user)
            # messages.success(request,"Successfully Logged In")
            # return render(request,'sentimentAnalyzer/index.html')
            return redirect('/')
        else:
            messages.error(request,"Invalid Credentials, Please try again")
            return redirect('/')

    return HttpResponse('404-Not Found')

def handleLogout(request):
    logout(request)
    messages.success(request, "Successfully Logged Out")
    return redirect('/')