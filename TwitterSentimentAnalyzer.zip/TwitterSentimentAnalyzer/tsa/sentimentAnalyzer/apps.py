from django.apps import AppConfig


class SentimentanalyzerConfig(AppConfig):
    name = 'sentimentAnalyzer'
